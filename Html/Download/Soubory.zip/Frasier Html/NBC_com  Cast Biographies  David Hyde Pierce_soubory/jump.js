
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->

	function openWirelessRegisterWindow()  {
		var eventId;
		var userId;
		var url;
		var left;
		var top;
		var iWidth;
		var iHeight;
		var settings;
		var urlName;
		var urlVariables;
		
		
		iWidth=screen.availWidth;
		iHeight=screen.availHeight;
		
		left=(iWidth-610)/2;
		top=(iHeight-420)/2;
		
		eventId= 10083;
		
		settings= "scrollbars=no,menubar=no,width=610,height=420,left="+left+",top="+top;
		
		urlName = "http://wireless.eventmatrix.com/Registration/Register.aspx";
		urlVariables = "?eid=" + eventId + "&uid=" + userId;
		
		url=urlName+urlVariables;
		window.open(url, "WirelessRegistration", settings);
	}
