<!--
function isWinIE() {
    if ((navigator.appVersion.indexOf("MSIE") != -1) &&  (navigator.appName.indexOf("Microsoft") != -1)) return true;
    else return false;
}
function isNS4() {
    if ((navigator.appVersion.indexOf("3.") != -1 || navigator.appVersion.indexOf("4.") != -1) &&  (navigator.appName.indexOf("Netscape") != -1)) return true; 

    ///if ((navigator.appVersion.indexOf("3.") != -1 || navigator.appVersion.indexOf("4.") != -1) &&  (navigator.appName.indexOf("Netscape") != -1) ||  (navigator.appVersion.indexOf("Macintosh") != -1)) return true;

    else return false;
}

if(isNS4()) {
document.write('<LINK rel="stylesheet" type="text/css" name="other" href="/nbc/Frasier/css/blue/other.css">');
//alert("Im using other.css - I must be using Netscape 3 or 4 or Im on a MAC" );
}
else {
document.write('<LINK rel="stylesheet" type="text/css" name="general" href="/nbc/Frasier/css/blue/general.css">');
}
// -->
