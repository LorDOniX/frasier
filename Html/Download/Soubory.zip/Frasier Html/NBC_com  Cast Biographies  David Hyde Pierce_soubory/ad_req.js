function ad_req(cid, bid, sid, pos) {
	var rand = rando();
	ad = new Image();
	var ad_uri = "http://ads.console.net/clear.gif?c=" + cid + "&b=" + bid + "&s=" + sid + "&p=" + pos + "&r=" + rand;
//	alert("nice try " + ad_uri);
	ad.src = ad_uri;
}


function rando() {

	var t = Math.random();
	u = t * 1000000000;
	l = Math.round(u);
	return l;

}
