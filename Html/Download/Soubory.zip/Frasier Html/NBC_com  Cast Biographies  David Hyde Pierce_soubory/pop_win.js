<!--//
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
function popSwap(theURL,winName,features) {
  self.name = "main"; // names current window as "main"
  window.open(theURL,"remote",features); // opens pop up window
}
function closePop() {
timer = setTimeout('window.close();', 10);
}

function openNewWindow(URLtoOpen, windowName, windowFeatures) {
newWindow=window.open(URLtoOpen, windowName, windowFeatures); 
}
