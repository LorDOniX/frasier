<!--//
app=navigator.appName.substring(0,1);
appver=navigator.appVersion.substring(0,1);
appvers=navigator.appVersion;

if ((navigator.appVersion.indexOf("MSIE") != -1) && (navigator.appName.indexOf("Microsoft") != -1) && (!navigator.appName.indexOf("Macintosh") != -1)) {
//if (isWinIE()) {
document.writeln('<div id="searchlocation">');
document.writeln('<table border=0 cellspacing=0 cellpadding=0><FORM METHOD="GET" ACTION="http://nbc.resultspage.com/display.php" NAME="SEARCHFORM">');
document.writeln('<tr><td valign="center" align="right"><input class="search" type="text" name="w" value="" size="10" maxlength="100"></td><td valign="center" align="right"><input class="search" type="image" src="http://www.nbc.com/imgs_color/blue/search_go.gif" border="0" name="go" width="61" height="18" hspace="4"></td></tr>');
document.writeln('</form></table>');
document.writeln('</div>');
}

else if (navigator.appName.indexOf("Internet Explorer")) { //(navigator.appName.indexOf == 'Internet Explorer') {
document.writeln('<div style="position:absolute; left: 360px; top: 3px; width: 250; height: 31px; z-index: 100;">');
document.writeln('<table border=0 cellspacing=0 cellpadding=0><FORM METHOD="GET" ACTION="http://nbc.resultspage.com/display.php" NAME="SEARCHFORM">');
document.writeln('<tr><td valign="center" align="right">');
document.writeln('<input class="search" type="text" name="w" value="" size="10" maxlength="100"></td><td valign="center" align="right"><input class="search" type="image" src="http://www.nbc.com/imgs_color/blue/search_go.gif" border="0" name="go" width="61" height="18" hspace="4"></td></tr>');
document.writeln('</form></table>');
document.writeln('</div>');
}

else if (app + appver == 'N4') {
document.writeln('<div id="searchlocation" overflow:x>');
document.writeln('<table border=0 cellspacing=0 cellpadding=0><FORM METHOD="GET" ACTION="http://nbc.resultspage.com/display.php" NAME="SEARCHFORM">');
document.writeln('<tr><td valign="center" align="right">');
document.writeln('<input class="search" type="text" name="w" value="" size=6 maxlength="100"></td><td valign="center" align="right"><input class="search" type="image" src="http://www.nbc.com/imgs_color/blue/search_go.gif" border="0" name="go" width="61" height="18" hspace="4"></td></tr>');
document.writeln('</form></table>');
document.writeln('</div>');
}

else {
document.writeln('<div id="searchlocation">');
document.writeln('<table border=0 cellspacing=0 cellpadding=0><FORM METHOD="GET" ACTION="http://nbc.resultspage.com/display.php" NAME="SEARCHFORM">');
document.writeln('<tr><td valign="center" align="right">');
document.writeln('<input class="search" type="text" name="w" value="" size=10 maxlength="100"></td><td valign="center" align="right"><input class="search" type="image" src="http://www.nbc.com/imgs_color/blue/search_go.gif" border="0" name="go" width="61" height="18" hspace="4"></td></tr>');
document.writeln('</form></table>');
document.writeln('</div>');
}
//-->
