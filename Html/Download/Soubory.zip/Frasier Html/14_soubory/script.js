function writeNav(){

	var here=location.pathname.substring(location.pathname.lastIndexOf("/")+1);

	document.write("<OBJECT classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\" codebase=\"http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0\" WIDTH=\"170\" HEIGHT=\"201\" id=\"hub\"><PARAM NAME=movie VALUE=\"/assets/swf/subnav.swf?selected="+here+"\"><PARAM NAME=menu VALUE=true> <PARAM NAME=quality VALUE=high> <PARAM NAME=bgcolor VALUE=#5D5D5D><EMBED src=\"/assets/swf/subnav.swf?selected="+here+"\" menu=true quality=high bgcolor=#5D5D5D  WIDTH=\"170\" HEIGHT=\"201\" NAME=\"hub\" TYPE=\"application/x-shockwave-flash\" PLUGINSPAGE=\"http://www.macromedia.com/go/getflashplayer\"></EMBED></OBJECT>")

}

function writeHub(forceday){
	var days = "sat-sun mon tues weds thurs fri sat-sun".split(" ");
	var day  = forceday?forceday:days[new Date().getDay()]

        // Transform the days to the appropriate format
        if(day.indexOf("tue") > -1)
        {
          day = "tues";
        }
        else if(day.indexOf("wed") > -1)
        {
          day = "weds";
        }
        else if(day.indexOf("thu") > -1)
        {
          day = "thurs";
        }
        else if(day.indexOf("sat") > -1 || day.indexOf("sun") > -1)
        {
          day = "sat-sun";
        } 
        
	var path = "/assets/swf/hub.swf?xml_src=homepage-"+day+".xml";
	var fla  = '<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"\
	 codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0"\
	 width="578" height="383">\
	 <param name="movie" value="'+path+'">\
	 <param name="quality" value="high">\
	 <embed src="'+path+'" quality="high" \
	 pluginspage="http://www.macromedia.com/go/getflashplayer" \
	 type="application/x-shockwave-flash" width="578" height="383"></embed></object>';
	 document.write(fla)
	 days=path=fla=day=null;
}
function writeHomepage(forceday){
	var days = "sat-sun mon tues weds thurs fri sat-sun".split(" ");
	var day  = forceday? forceday : days[new Date().getDay()]; 
        // Transform the days to the appropriate format
		if(day.indexOf("mon") > -1)//incase it's passed 'homepage-mon.xml'
		{
			day="mon";
		}
        if(day.indexOf("tue") > -1)
        {
          day = "tues";
        }
        else if(day.indexOf("wed") > -1)
        {
          day = "weds";
        }
        else if(day.indexOf("thu") > -1)
        {
          day = "thurs";
        }
        else if(day.indexOf("sat") > -1 || day.indexOf("sun") > -1)
        {
          day = "sat-sun";
        }

	var path = "/_content/homepage.swf?xml_src=homepage-"+day+".xml";
	var fla  = '<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"\
	 codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0"\
	 width="737" height="427">\
	 <param name="movie" value="'+path+'">\
	 <param name="quality" value="high">\
	 <embed src="'+path+'" quality="high" \
	 pluginspage="http://www.macromedia.com/go/getflashplayer" \
	 type="application/x-shockwave-flash" width="737" height="427"></embed></object>';
	 document.write(fla);
	 days=path=fla=forceday=null;
}



function pickAShow(){
	var prefix = "/television/";
	var selected="";
	var shows=new Array(
		{url:"7th-heaven", 	 display:"7th Heaven"},
		{url:"becker", 		 display:"Becker"},
                {url:"bramandalice",           display:"Bram and Alice"},
		{url:"charmed", 	 display:"Charmed"},
		{url:"chris-isaak",  display:"The Chris Isaak "},
			{url:"chris-isaak",  display:"&nbsp;&nbsp; Show"},		
		{url:"deadzone",  	display:"The Dead Zone"},
		{url:"division", 	 display:"The Division"},
                {url:"do-over",           display:"Do Over"},
                {url:"dr-phil",           display:"Dr. Phil"},
		{url:"ed", 			 display:"Ed"},
		{url:"enterprise",	 display:"Enterprise"},
		{url:"ent-tonight",  display:"Entertainment"},	
			{url:"ent-tonight",  display:"&nbsp;&nbsp; Tonight"},			
		{url:"frasier", 	 display:"Frasier"},
		{url:"girlfriends",  display:"Girlfriends"},
                {url:"greetings-tucson",  display:"Greetings From"},
                        {url:"greetings-tucson",  display:"&nbsp;&nbsp; Tucson"},
                {url:"hack",          display:"Hack"},
                {url:"haunted",          display:"Haunted"},
		{url:"hot-ticket", 	 display:"Hot Ticket"},
                {url:"in-laws",          display:"In-Laws"},
		{url:"jag", 	 display:"JAG"},
		{url:"jamie-kennedy",display:"The Jamie "},
			{url:"jamie-kennedy",display:"&nbsp;&nbsp; Kennedy "},		
			{url:"jamie-kennedy",display:"&nbsp;&nbsp; Experiment "},		
		{url:"judge-joe", 	 display:"Judge Joe Brown"},
		{url:"judge-judy", 	 display:"Judge Judy"},		
                {url:"life-moments",          display:"Life Moments"},
		{url:"max-ex", 	 	 display:"Maximum "},
			{url:"max-ex", 	 	 display:"&nbsp;&nbsp; Exposure"},		
		{url:"montel", 	 	 display:"Montel Williams"},
		{url:"oneonone", 	 display:"One on One"},
		{url:"parkers", 	 display:"The Parkers"},
		{url:"resblvd", 	 display:"Resurrection Blvd."},	
		{url:"sabrina", 	 display:"Sabrina the "},
			{url:"sabrina", 	 display:"&nbsp; Teenage Witch"},		
		{url:"small-shots",  display:"Small Shots"},
		{url:"soulfood", 	 display:"Soul Food"}
	);
	document.write("<option value=\"\">--Pick a Show--</option>");
	for(i=0;i<shows.length;i++){
		var urlpath  = prefix + shows[i]["url"]+ "/";
		var disp = shows[i]["display"];
		selected = (location.pathname.indexOf(urlpath)>-1 && !selected)?" selected":"";
		document.write("<option value=\""+ urlpath +"\""+ selected +">" + disp + "</option>");
	}
}

function openGallery(title,xmlsrc,path){
	 if(!title)title="Gallery";
	// var here=location.pathname.substring(0,location.pathname.lastIndexOf("/")+1);
	if(!path)
		path=xmlsrc.substring(0,xmlsrc.lastIndexOf("/"))+"/_content/";
	if(!xmlsrc)
		xmlsrc=location.pathname.substring(0,location.pathname.lastIndexOf("/"))+"/"+title+"-gallery.xml";
	 var w=358;var h=544;
	 var swfsrc="/assets/swf/gallery.swf?xml_src="+xmlsrc+"&show="+title;
	 var content="<HTML><HEAD><TITLE>"+title+"</TITLE><link rel=stylesheet href=/style.css></HEAD><BODY topmargin=0 leftmargin=0 bottommargin=0 marginwidth=0 marginheight=0><OBJECT classid=clsid:D27CDB6E-AE6D-11cf-96B8-444553540000 codebase=\"http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0\" WIDTH="+w+" HEIGHT="+h+" id=gallery><PARAM NAME=movie VALUE=\""+swfsrc+"\"><PARAM NAME=quality VALUE=high><PARAM NAME=bgcolor VALUE=#FFFFFF><EMBED src=\""+swfsrc+"\" quality=high bgcolor=#FFFFFF WIDTH="+w+" HEIGHT="+h+" NAME=gallery TYPE=\"application/x-shockwave-flash\" PLUGINSPAGE=\"http://www.macromedia.com/go/getflashplayer\"></EMBED></OBJECT></BODY></HTML>";
	var wnd=window.open("about:blank","galleryWnd","width="+w+",height="+h+",left=100,top=100");
	with(wnd){
		document.open();
		document.write(content);
		document.close();
	}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}



function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}



function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}



function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}

function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}


var requiredVersion = 6;   
var upgradePage = "/upgrade.htm";

var flash2Installed = false;    
var flash3Installed = false;    
var flash4Installed = false;    
var flash5Installed = false;    
var flash6Installed = false;    
var flash7Installed = false;
var maxVersion = 7;             
var actualVersion = 0;          
var hasRightVersion = false;    
var jsVersion = 1.0;            

var isIE = (navigator.appVersion.indexOf("MSIE") != -1) ? true : false;    
var isWin = (navigator.appVersion.indexOf("Windows") != -1) ? true : false; 

jsVersion = 1.1;

if(isIE && isWin){
	document.write('<SCR' + 'IPT LANGUAGE=VBScript\> \n');
	document.write('on error resume next \n');
	document.write('flash2Installed = (IsObject(CreateObject("ShockwaveFlash.ShockwaveFlash.2"))) \n');
	document.write('flash3Installed = (IsObject(CreateObject("ShockwaveFlash.ShockwaveFlash.3"))) \n');
	document.write('flash4Installed = (IsObject(CreateObject("ShockwaveFlash.ShockwaveFlash.4"))) \n');
	document.write('flash5Installed = (IsObject(CreateObject("ShockwaveFlash.ShockwaveFlash.5"))) \n');  
	document.write('flash6Installed = (IsObject(CreateObject("ShockwaveFlash.ShockwaveFlash.6"))) \n');  
        document.write('flash7Installed = (IsObject(CreateObject("ShockwaveFlash.ShockwaveFlash.7"))) \n');
	document.write('</SCR' + 'IPT\> \n'); 
}

function detectFlash() {  
	if(navigator.plugins) {
		if(typeof(navigator.plugins.refresh)=="function")
			navigator.plugins.refresh();
		if (navigator.plugins["Shockwave Flash 2.0"]|| navigator.plugins["Shockwave Flash"]) {
			var isVersion2 = navigator.plugins["Shockwave Flash 2.0"] ? " 2.0" : "";
			var flashDescription = navigator.plugins["Shockwave Flash" + isVersion2].description;
      		var flashVersion = parseInt(flashDescription.charAt(flashDescription.indexOf(".") - 1));
			flash2Installed = flashVersion == 2;    
			flash3Installed = flashVersion == 3;
			flash4Installed = flashVersion == 4;
			flash5Installed = flashVersion == 5;
			flash6Installed = flashVersion >= 6;
		}
  }
	for(i=2;i<=maxVersion;i++) if(eval("flash" + i + "Installed") == true)actualVersion=i;

  	if(navigator.userAgent.indexOf("WebTV")!=-1)actualVersion=3;  
	if(actualVersion < requiredVersion && !(isIE && isWin)){
		if(location.href.indexOf(upgradePage)==-1)
			location.href=upgradePage;
		return;
	}else{
		void(0);//nothing because they have it. just want to display the dang page
	}
		
}

detectFlash();  



