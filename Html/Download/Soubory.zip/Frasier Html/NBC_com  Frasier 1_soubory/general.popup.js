URL = window.location.href;
//test for URL
isgrace = (URL.indexOf('/Will_&_Grace/') > -1);
URL = window.location.href;
isfriends = (URL.indexOf('/Friends/') > -1);
URL = window.location.href;
iser = (URL.indexOf('/ER/') > -1);
URL = window.location.href;
isfrasier = (URL.indexOf('/Frasier/') > -1);
URL = window.location.href;
islaw = (URL.indexOf('/Law_&_Order/') > -1);
URL = window.location.href;
iswestwing = (URL.indexOf('/The_West_Wing/') > -1);

//If URL then do
if (iser) {
document.write('<SCRIPT SRC="/js_scripts/er.js">');
document.write('<\/SCRIPT>');
}
if (isgrace) {
document.write('<SCRIPT SRC="/js_scripts/willngrace.js">');
document.write('<\/SCRIPT>');
}
if (isfriends) {
document.write('<SCRIPT SRC="/js_scripts/friends.js">');
document.write('<\/SCRIPT>');
}
if (iswestwing) {
document.write('<SCRIPT SRC="/js_scripts/westwing.js">');
document.write('<\/SCRIPT>');
}
