

<!--
function isWinIE() {
if ((navigator.appVersion.indexOf("MSIE") != -1) && (navigator.appName.indexOf("Microsoft") != -1)) return true;
else return false;
}

function isMac() {
if (navigator.appVersion.indexOf("Macintosh") != -1) return true;
else return false;
}

function isNS3() {
if (navigator.appVersion.indexOf("2.") != -1 || navigator.appVersion.indexOf("3. ") != -1) return true;
else return false;
}

if (isWinIE()) {
document.write('<LINK rel="stylesheet" type="text/css" name="ie" href="/css/ie.css">');

}
else if(isMac()) {
document.write('<LINK rel="stylesheet" type="text/css" name="mac" href="/css/mac.css">');
}
else {
document.write('<LINK rel="stylesheet" type="text/css" name="other" href="/css/other.css">');
}
// -->

