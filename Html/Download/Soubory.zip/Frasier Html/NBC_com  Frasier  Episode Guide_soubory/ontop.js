

<!--

function MM_findObj(n, d) { //v3.0
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document); return x;
}

function tmt_DivOnTop(theDiv){
	var t = 0;var z = (document.layers) ? ".zIndex" : ".style.zIndex";
	var fun = (document.getElementById) ? "document.getElementById" : "MM_findObj";
	var arr = (document.layers) ? document.layers : (document.all) ? document.all.tags("DIV") : document.getElementsByTagName("DIV");
	for(var i=0;i<arr.length;i++){var oz = eval("arr["+i+"]"+z);if(oz > t){t = oz;}}
	var obj = eval(fun+"(theDiv)");if(obj)eval(fun+"('"+theDiv+"')"+z+"=parseInt("+t+")+1");
}
//-->

